package com.example.weatherapp

data class ForcastTemp(
    val day: Float,
    val min: Float,
    val max: Float,
)