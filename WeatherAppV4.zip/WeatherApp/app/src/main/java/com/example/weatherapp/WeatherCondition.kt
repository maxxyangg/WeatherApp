package com.example.weatherapp

data class WeatherCondition(
    val main: String,
    val icon: String,
)

