package com.example.weatherapp

data class Forecast(
    val list: List<DayForecast>,

    )